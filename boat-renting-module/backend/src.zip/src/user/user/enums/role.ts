export enum Role {
  Admin = "admin",
  Channel = "channel",
  Event = "event",
  Client = "client",
}
