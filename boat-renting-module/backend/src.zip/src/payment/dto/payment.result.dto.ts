class PaymentResultDto {
  success: boolean;
  message: string;
  paymentId: string | null;
}
