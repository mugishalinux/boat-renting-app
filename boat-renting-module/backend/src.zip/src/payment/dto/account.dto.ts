export class AccountDto {
  card: string;
  cvv: string;
  expire: any;
}
