import React from "react";

import "./about.scss";

const AboutUs = () => {
    <div>
        <h1>hello</h1>
    </div>
};

export default AboutUs;
