import React from "react";
import './Loading'
function Loading(props){
 return (
     <div>
      <div className="lds-facebook"><div>
          </div>
          <div>
              </div>
              <div>
                  </div>
                  </div>
     </div>

 );
}
export default Loading;