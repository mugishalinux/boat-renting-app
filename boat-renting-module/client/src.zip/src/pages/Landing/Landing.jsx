import Sidebar from "../../components/sidebar/Sidebar";
const Landing = () => {
  return (
    <div className="home">
      <Sidebar />
    </div>
  );
};

export default Landing;
